1. Worked with Rachael Robinson, Josh Berl, and David McConell.
2. 8 hours
3. As far as I know, everything was correctly implemented